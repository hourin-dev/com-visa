# VisaDesk v2 — 외국인 비자 통합 관리 플랫폼

**법무법인 대림** | FastAPI + SQLite/PostgreSQL + HTML 프론트엔드

---

## 🗂️ 프로젝트 구조

```
visadesk/
├── backend/
│   ├── main.py          ← FastAPI 메인 앱 (API 라우터 포함)
│   ├── models.py        ← SQLAlchemy DB 모델
│   ├── auth.py          ← JWT 인증, 권한 관리
│   └── .env             ← 환경 변수 (SECRET_KEY 등)
├── frontend/
│   └── index.html       ← 전체 프론트엔드 (단일 HTML)
├── requirements.txt
├── start.sh             ← 로컬 실행 스크립트
├── railway.toml         ← Railway 배포 설정
└── Procfile             ← Railway/Heroku 실행 명령
```

---

## ⚡ 로컬 실행

```bash
# 1. 패키지 설치
pip install -r requirements.txt

# 2. 서버 시작
bash start.sh
# 또는
cd backend && python main.py

# 3. 브라우저에서 frontend/index.html 열기
#    (또는 http://localhost:8000 접속)
```

## 🔑 데모 계정

| 역할 | 아이디 | 비밀번호 |
|------|--------|----------|
| 비자관리자 | admin | 1234 |
| 업체관리자 | company1 | 1234 |
| 외국인직원 | emp1 | 1234 |

---

## 🚀 Railway 배포 (권장)

### 1단계: GitHub에 코드 올리기
```bash
git init
git add .
git commit -m "VisaDesk v2 초기 배포"
git remote add origin https://github.com/YOUR_ID/visadesk.git
git push -u origin main
```

### 2단계: Railway 배포
1. https://railway.app 접속 → GitHub 로그인
2. **New Project** → **Deploy from GitHub repo**
3. visadesk 저장소 선택
4. **Add PostgreSQL** 클릭 (DB 자동 생성)
5. 환경변수 추가:
   ```
   SECRET_KEY = [강력한-랜덤-문자열]
   DATABASE_URL = (Railway가 자동 주입)
   ```
6. 배포 완료 → `https://visadesk-xxxx.up.railway.app` URL 생성

### 3단계: 프론트엔드 API 주소 변경
`frontend/index.html` 상단의 API 주소를 수정:
```javascript
const API = 'https://visadesk-xxxx.up.railway.app';  // Railway URL로 변경
```

---

## 🔐 운영 보안 설정

`.env` 파일 필수 수정:
```env
SECRET_KEY=매우-복잡한-랜덤-문자열-32자이상-필수
DATABASE_URL=postgresql://user:pass@host/dbname  # PostgreSQL로 변경
```

---

## 📡 API 문서

서버 실행 후 http://localhost:8000/docs 에서 Swagger UI 확인 가능

### 주요 엔드포인트
| 메서드 | URL | 설명 |
|--------|-----|------|
| POST | /api/auth/login | 로그인 |
| GET | /api/dashboard | 대시보드 통계 |
| GET | /api/employees | 직원 목록 |
| POST | /api/employees | 직원 등록 |
| GET | /api/issues | 의뢰 목록 |
| POST | /api/issues | 의뢰 등록 |
| PATCH | /api/issues/{id} | 의뢰 상태 업데이트 |
| GET | /api/companies | 업체 목록 (관리자) |
| POST | /api/companies | 업체 등록 (관리자) |
| GET | /api/users | 계정 목록 (관리자) |
| POST | /api/users | 계정 생성 (관리자) |

---

## 🗓️ 버전 로드맵

- **v1**: HTML 단독 파일 (LocalStorage)
- **v2**: FastAPI + SQLite + HTML 프론트엔드 ← **현재**
- **v3**: PostgreSQL 전환 + 이메일 알림 + 다국어 지원
- **v4**: 모바일 앱 + 자동화 + AI 리스크 감지
