from sqlalchemy import create_engine, Column, String, Boolean, Date, DateTime, Integer, Text, Enum, Numeric, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import uuid, os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./visadesk.db")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def new_id():
    return str(uuid.uuid4())[:8]

# ─────────────────────────────────────────
class Company(Base):
    __tablename__ = "companies"
    id          = Column(String, primary_key=True, default=new_id)
    name        = Column(String(100), nullable=False)
    biz_number  = Column(String(20), unique=True)
    industry    = Column(String(60))
    address     = Column(Text)
    contact     = Column(String(50))
    phone       = Column(String(20))
    email       = Column(String(100))
    memo        = Column(Text)
    status      = Column(String(10), default="active")
    created_at  = Column(DateTime, default=datetime.utcnow)

    users       = relationship("User", back_populates="company")
    employees   = relationship("Employee", back_populates="company")
    issues      = relationship("Issue", back_populates="company")

class User(Base):
    __tablename__ = "users"
    id          = Column(String, primary_key=True, default=new_id)
    company_id  = Column(String, ForeignKey("companies.id"), nullable=True)
    role        = Column(String(20), nullable=False)   # visa_admin | company_admin | employee
    username    = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(200), nullable=False)
    name        = Column(String(80))
    email       = Column(String(100))
    phone       = Column(String(20))
    language    = Column(String(10), default="ko")
    is_active   = Column(Boolean, default=True)
    last_login  = Column(DateTime)
    created_at  = Column(DateTime, default=datetime.utcnow)

    company     = relationship("Company", back_populates="users")
    employee    = relationship("Employee", back_populates="user", uselist=False)

class Employee(Base):
    __tablename__ = "employees"
    id              = Column(String, primary_key=True, default=new_id)
    user_id         = Column(String, ForeignKey("users.id"), nullable=True)
    company_id      = Column(String, ForeignKey("companies.id"), nullable=False)
    korean_name     = Column(String(60), nullable=False)
    native_name     = Column(String(100))
    nationality     = Column(String(40))
    birth_date      = Column(String(12))
    gender          = Column(String(4))
    passport_no     = Column(String(20))
    passport_expiry = Column(String(12))
    alien_reg_no    = Column(String(20))
    phone           = Column(String(20))
    address         = Column(Text)
    emergency_contact = Column(String(20))
    # Visa
    visa_type       = Column(String(10))
    visa_status     = Column(String(20), default="정상")
    entry_date      = Column(String(12))
    expiry_date     = Column(String(12))
    alien_card_expiry = Column(String(12))
    workplace_restriction = Column(Boolean, default=False)
    reentry_permit  = Column(Boolean, default=False)
    reentry_expiry  = Column(String(12))
    remarks         = Column(Text)
    created_at      = Column(DateTime, default=datetime.utcnow)
    updated_at      = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    company         = relationship("Company", back_populates="employees")
    user            = relationship("User", back_populates="employee")
    issues          = relationship("Issue", back_populates="employee")
    documents       = relationship("Document", back_populates="employee")

class Issue(Base):
    __tablename__ = "issues"
    id              = Column(String, primary_key=True, default=new_id)
    employee_id     = Column(String, ForeignKey("employees.id"), nullable=False)
    company_id      = Column(String, ForeignKey("companies.id"), nullable=False)
    issue_type      = Column(String(30))
    title           = Column(String(200))
    description     = Column(Text)
    urgency         = Column(String(10))   # 즉시|1주내|1개월내|여유있음
    status          = Column(String(10), default="접수")  # 접수|검토중|처리중|완료|보류
    assigned_to     = Column(String(80))
    request_date    = Column(DateTime, default=datetime.utcnow)
    resolution_date = Column(DateTime, nullable=True)
    resolution_note = Column(Text)
    fee_amount      = Column(Numeric(12,0), nullable=True)
    fee_status      = Column(String(10), default="미청구")
    created_by      = Column(String, ForeignKey("users.id"), nullable=True)

    employee        = relationship("Employee", back_populates="issues")
    company         = relationship("Company", back_populates="issues")

class Document(Base):
    __tablename__ = "documents"
    id          = Column(String, primary_key=True, default=new_id)
    employee_id = Column(String, ForeignKey("employees.id"), nullable=False)
    issue_id    = Column(String, ForeignKey("issues.id"), nullable=True)
    doc_type    = Column(String(50))
    file_name   = Column(String(200))
    file_path   = Column(String(500))
    uploaded_by = Column(String, ForeignKey("users.id"), nullable=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    expiry_date = Column(String(12), nullable=True)

    employee    = relationship("Employee", back_populates="documents")

class Alert(Base):
    __tablename__ = "alerts"
    id              = Column(String, primary_key=True, default=new_id)
    employee_id     = Column(String, ForeignKey("employees.id"), nullable=False)
    company_id      = Column(String, ForeignKey("companies.id"), nullable=False)
    alert_type      = Column(String(30))
    days_remaining  = Column(Integer)
    is_read         = Column(Boolean, default=False)
    created_at      = Column(DateTime, default=datetime.utcnow)
