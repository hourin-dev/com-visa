from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import or_
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, date, timedelta
import os, sys

# Add backend dir to path
sys.path.insert(0, os.path.dirname(__file__))

from models import Base, engine, get_db, User, Company, Employee, Issue, Document, Alert, new_id
from auth import (hash_password, verify_password, create_token, get_current_user,
                  require_role, get_company_filter)

# ── Create tables & seed demo data ──────────────────────────────────────────
Base.metadata.create_all(bind=engine)

def seed_demo(db: Session):
    if db.query(User).filter(User.username == "admin").first():
        return
    # Companies
    c1 = Company(id="c1", name="(주)서울기공", biz_number="123-45-67890", industry="금속제조업", address="서울시 구로구 공단로 123", contact="김철수", phone="010-1234-5678", email="kim@seoultech.kr")
    c2 = Company(id="c2", name="글로벌제조㈜", biz_number="987-65-43210", industry="전자부품제조", address="경기도 시흥시 공단1로 456", contact="이영희", phone="010-9876-5432", email="lee@global.co.kr")
    c3 = Company(id="c3", name="우리농업협동조합", biz_number="111-22-33333", industry="농업", address="충청남도 천안시 동남구 농업로 789", contact="박민준", phone="010-5555-6666", email="park@woori.kr")
    db.add_all([c1, c2, c3])
    # Users
    u_admin = User(id="u1", role="visa_admin", username="admin", password_hash=hash_password("1234"), name="사무장 호우린", email="admin@daelim.kr")
    u_c1    = User(id="u2", company_id="c1", role="company_admin", username="company1", password_hash=hash_password("1234"), name="김철수 (HR)", email="kim@seoultech.kr")
    u_c2    = User(id="u3", company_id="c2", role="company_admin", username="company2", password_hash=hash_password("1234"), name="이영희 (총무)", email="lee@global.co.kr")
    u_e1    = User(id="u4", company_id="c1", role="employee", username="emp1", password_hash=hash_password("1234"), name="Wang Lei (왕뢰)")
    u_e2    = User(id="u5", company_id="c2", role="employee", username="emp2", password_hash=hash_password("1234"), name="Nguyen Van A")
    db.add_all([u_admin, u_c1, u_c2, u_e1, u_e2])
    # Employees
    e1 = Employee(id="e1", user_id="u4", company_id="c1", korean_name="왕뢰", native_name="Wang Lei", nationality="중국", birth_date="1990-05-15", gender="남", passport_no="G12345678", passport_expiry="2028-05-14", alien_reg_no="901234-5678901", phone="010-1111-2222", address="서울시 영등포구 당산동 1-1", visa_type="E-9", visa_status="정상", entry_date="2022-03-01", expiry_date="2026-08-31", alien_card_expiry="2026-08-31", workplace_restriction=True)
    e2 = Employee(id="e2", company_id="c1", korean_name="이후안", native_name="Li Huan", nationality="중국", birth_date="1988-11-20", gender="여", passport_no="E98765432", passport_expiry="2027-11-19", alien_reg_no="881234-6789012", phone="010-2222-3333", address="서울시 영등포구 문래동 2-2", visa_type="H-2", visa_status="만료임박", entry_date="2021-06-15", expiry_date="2026-04-20", alien_card_expiry="2026-04-20", workplace_restriction=False)
    e3 = Employee(id="e3", user_id="u5", company_id="c2", korean_name="응우옌반안", native_name="Nguyen Van A", nationality="베트남", birth_date="1995-03-08", gender="남", passport_no="B11223344", passport_expiry="2029-03-07", alien_reg_no="950123-5678901", phone="010-7777-8888", address="경기도 시흥시 정왕동 3-3", visa_type="E-9", visa_status="정상", entry_date="2023-01-10", expiry_date="2027-01-09", alien_card_expiry="2027-01-09", workplace_restriction=True)
    e4 = Employee(id="e4", company_id="c2", korean_name="팜티훙", native_name="Pham Thi Hong", nationality="베트남", birth_date="1993-07-22", gender="여", passport_no="C55667788", passport_expiry="2026-05-01", alien_reg_no="930456-6789012", phone="010-8888-9999", address="경기도 시흥시 신천동 4-4", visa_type="E-7", visa_status="만료임박", entry_date="2020-09-01", expiry_date="2026-04-15", alien_card_expiry="2026-04-15", workplace_restriction=False)
    e5 = Employee(id="e5", company_id="c3", korean_name="카림", native_name="Karim Rahman", nationality="방글라데시", birth_date="1987-02-14", gender="남", passport_no="D99001122", passport_expiry="2026-08-31", alien_reg_no="870234-5000001", phone="010-3456-7890", address="충청남도 천안시 동남구 5-5", visa_type="E-9", visa_status="갱신필요", entry_date="2019-04-01", expiry_date="2026-05-30", alien_card_expiry="2026-05-30", workplace_restriction=True)
    db.add_all([e1, e2, e3, e4, e5])
    # Issues
    i1 = Issue(id="i1", employee_id="e2", company_id="c1", issue_type="비자만료임박", title="H-2 비자 만료 갱신 요청", description="2026년 4월 20일 체류 만료 예정. 동포자격 유지 여부 검토 후 재신청 필요", urgency="즉시", status="처리중", assigned_to="사무장 호우린")
    i2 = Issue(id="i2", employee_id="e4", company_id="c2", issue_type="체류자격변경", title="E-7 체류자격 갱신", description="현 고용주와 계약 연장. 체류자격 변경 신청 필요", urgency="1개월내", status="검토중", assigned_to="사무장 호우린")
    i3 = Issue(id="i3", employee_id="e5", company_id="c3", issue_type="불법체류위험", title="E-9 갱신 지연 긴급 처리", description="체류 만료 임박. 사업주 사정으로 신청 지연됨. 긴급 처리 요망", urgency="즉시", status="접수", assigned_to="미배정")
    db.add_all([i1, i2, i3])
    db.commit()

db_session = next(get_db())
try:
    seed_demo(db_session)
finally:
    db_session.close()

# ── FastAPI App ──────────────────────────────────────────────────────────────
app = FastAPI(title="VisaDesk API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
static_dir = os.path.join(os.path.dirname(__file__), "..", "frontend", "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

# ── Pydantic Schemas ─────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class CompanyCreate(BaseModel):
    name: str
    biz_number: Optional[str] = None
    industry: Optional[str] = None
    address: Optional[str] = None
    contact: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    memo: Optional[str] = None

class EmployeeCreate(BaseModel):
    company_id: str
    korean_name: str
    native_name: Optional[str] = None
    nationality: Optional[str] = None
    birth_date: Optional[str] = None
    gender: Optional[str] = None
    passport_no: Optional[str] = None
    passport_expiry: Optional[str] = None
    alien_reg_no: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    emergency_contact: Optional[str] = None
    visa_type: Optional[str] = None
    visa_status: Optional[str] = "정상"
    entry_date: Optional[str] = None
    expiry_date: Optional[str] = None
    alien_card_expiry: Optional[str] = None
    workplace_restriction: Optional[bool] = False
    reentry_permit: Optional[bool] = False
    reentry_expiry: Optional[str] = None
    remarks: Optional[str] = None

class IssueCreate(BaseModel):
    employee_id: str
    issue_type: str
    title: str
    description: Optional[str] = None
    urgency: str
    assigned_to: Optional[str] = "미배정"

class IssueUpdate(BaseModel):
    status: Optional[str] = None
    assigned_to: Optional[str] = None
    resolution_note: Optional[str] = None
    fee_amount: Optional[float] = None
    fee_status: Optional[str] = None

class UserCreate(BaseModel):
    company_id: Optional[str] = None
    role: str
    username: str
    password: str
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None

# ── Helper ────────────────────────────────────────────────────────────────────
def days_until(date_str: str) -> int:
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d").date()
        return (d - date.today()).days
    except:
        return 9999

def emp_to_dict(e: Employee, include_company=True) -> dict:
    d = {
        "id": e.id, "company_id": e.company_id,
        "korean_name": e.korean_name, "native_name": e.native_name,
        "nationality": e.nationality, "birth_date": e.birth_date,
        "gender": e.gender, "passport_no": e.passport_no,
        "passport_expiry": e.passport_expiry,
        "alien_reg_no": e.alien_reg_no,
        "phone": e.phone, "address": e.address,
        "emergency_contact": e.emergency_contact,
        "visa_type": e.visa_type, "visa_status": e.visa_status,
        "entry_date": e.entry_date, "expiry_date": e.expiry_date,
        "alien_card_expiry": e.alien_card_expiry,
        "workplace_restriction": e.workplace_restriction,
        "reentry_permit": e.reentry_permit, "reentry_expiry": e.reentry_expiry,
        "remarks": e.remarks,
        "days_until_expiry": days_until(e.expiry_date) if e.expiry_date else None,
        "created_at": e.created_at.strftime("%Y-%m-%d") if e.created_at else None,
    }
    if include_company and e.company:
        d["company_name"] = e.company.name
    return d

def issue_to_dict(i: Issue, include_employee=True) -> dict:
    d = {
        "id": i.id, "employee_id": i.employee_id, "company_id": i.company_id,
        "issue_type": i.issue_type, "title": i.title, "description": i.description,
        "urgency": i.urgency, "status": i.status, "assigned_to": i.assigned_to,
        "request_date": i.request_date.strftime("%Y-%m-%d") if i.request_date else None,
        "resolution_date": i.resolution_date.strftime("%Y-%m-%d") if i.resolution_date else None,
        "resolution_note": i.resolution_note,
        "fee_amount": float(i.fee_amount) if i.fee_amount else None,
        "fee_status": i.fee_status,
    }
    if include_employee and i.employee:
        d["employee_name"] = i.employee.korean_name
        d["company_name"] = i.company.name if i.company else ""
    return d

# ── Routes ───────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    index = os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html")
    if os.path.exists(index):
        return FileResponse(index)
    return {"message": "VisaDesk API v2.0", "docs": "/docs"}

@app.post("/api/auth/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == req.username, User.is_active == True).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="아이디 또는 비밀번호가 올바르지 않습니다")
    user.last_login = datetime.utcnow()
    db.commit()
    token = create_token({"sub": user.id, "role": user.role})
    company_name = user.company.name if user.company else "법무법인 대림"
    emp_id = user.employee.id if user.employee else None
    return {
        "access_token": token, "token_type": "bearer",
        "user": {
            "id": user.id, "role": user.role, "name": user.name,
            "username": user.username, "company_id": user.company_id,
            "company_name": company_name, "employee_id": emp_id,
        }
    }

@app.get("/api/auth/me")
def me(current_user: User = Depends(get_current_user)):
    company_name = current_user.company.name if current_user.company else "법무법인 대림"
    return {
        "id": current_user.id, "role": current_user.role, "name": current_user.name,
        "username": current_user.username, "company_id": current_user.company_id,
        "company_name": company_name,
        "employee_id": current_user.employee.id if current_user.employee else None,
    }

# ── Companies ─────────────────────────────────────────────────────────────────
@app.get("/api/companies")
def list_companies(current_user: User = Depends(require_role("visa_admin")), db: Session = Depends(get_db)):
    companies = db.query(Company).filter(Company.status == "active").all()
    result = []
    for c in companies:
        emp_count = db.query(Employee).filter(Employee.company_id == c.id).count()
        open_issues = db.query(Issue).filter(Issue.company_id == c.id, Issue.status != "완료").count()
        result.append({
            "id": c.id, "name": c.name, "biz_number": c.biz_number,
            "industry": c.industry, "contact": c.contact, "phone": c.phone,
            "email": c.email, "address": c.address,
            "employee_count": emp_count, "open_issues": open_issues,
            "created_at": c.created_at.strftime("%Y-%m-%d") if c.created_at else None,
        })
    return result

@app.post("/api/companies")
def create_company(data: CompanyCreate, current_user: User = Depends(require_role("visa_admin")), db: Session = Depends(get_db)):
    c = Company(**data.dict())
    db.add(c)
    db.commit()
    db.refresh(c)
    return {"id": c.id, "name": c.name, "message": "업체가 등록되었습니다"}

# ── Employees ─────────────────────────────────────────────────────────────────
@app.get("/api/employees")
def list_employees(
    q: Optional[str] = None,
    visa_type: Optional[str] = None,
    expiring_days: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    cid = get_company_filter(current_user)
    query = db.query(Employee)
    if cid:
        query = query.filter(Employee.company_id == cid)
    if q:
        query = query.filter(or_(
            Employee.korean_name.contains(q),
            Employee.native_name.contains(q),
            Employee.nationality.contains(q),
            Employee.alien_reg_no.contains(q),
        ))
    if visa_type:
        query = query.filter(Employee.visa_type == visa_type)
    emps = query.order_by(Employee.created_at.desc()).all()
    result = [emp_to_dict(e) for e in emps]
    if expiring_days is not None:
        result = [r for r in result if r.get("days_until_expiry") is not None and r["days_until_expiry"] <= expiring_days]
    return result

@app.get("/api/employees/{emp_id}")
def get_employee(emp_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.role == "employee":
        if not current_user.employee or current_user.employee.id != emp_id:
            raise HTTPException(status_code=403, detail="본인 정보만 조회 가능합니다")
    emp = db.query(Employee).filter(Employee.id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="직원을 찾을 수 없습니다")
    cid = get_company_filter(current_user)
    if cid and emp.company_id != cid:
        raise HTTPException(status_code=403, detail="접근 권한이 없습니다")
    return emp_to_dict(emp)

@app.post("/api/employees")
def create_employee(data: EmployeeCreate, current_user: User = Depends(require_role("visa_admin","company_admin")), db: Session = Depends(get_db)):
    cid = get_company_filter(current_user)
    if cid and data.company_id != cid:
        raise HTTPException(status_code=403, detail="본인 업체에만 등록 가능합니다")
    e = Employee(**data.dict())
    db.add(e)
    db.commit()
    db.refresh(e)
    return {"id": e.id, "korean_name": e.korean_name, "message": "직원이 등록되었습니다"}

@app.put("/api/employees/{emp_id}")
def update_employee(emp_id: str, data: EmployeeCreate, current_user: User = Depends(require_role("visa_admin","company_admin")), db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="직원을 찾을 수 없습니다")
    cid = get_company_filter(current_user)
    if cid and emp.company_id != cid:
        raise HTTPException(status_code=403, detail="접근 권한이 없습니다")
    for k, v in data.dict().items():
        setattr(emp, k, v)
    emp.updated_at = datetime.utcnow()
    db.commit()
    return {"message": "수정되었습니다"}

# ── Issues ────────────────────────────────────────────────────────────────────
@app.get("/api/issues")
def list_issues(
    status: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    cid = get_company_filter(current_user)
    query = db.query(Issue)
    if current_user.role == "employee":
        if current_user.employee:
            query = query.filter(Issue.employee_id == current_user.employee.id)
        else:
            return []
    elif cid:
        query = query.filter(Issue.company_id == cid)
    if status:
        query = query.filter(Issue.status == status)
    issues = query.order_by(Issue.request_date.desc()).all()
    return [issue_to_dict(i) for i in issues]

@app.post("/api/issues")
def create_issue(data: IssueCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    emp = db.query(Employee).filter(Employee.id == data.employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="직원을 찾을 수 없습니다")
    cid = get_company_filter(current_user)
    if cid and emp.company_id != cid:
        raise HTTPException(status_code=403, detail="접근 권한이 없습니다")
    issue = Issue(
        employee_id=data.employee_id, company_id=emp.company_id,
        issue_type=data.issue_type, title=data.title, description=data.description,
        urgency=data.urgency, assigned_to=data.assigned_to, created_by=current_user.id,
    )
    db.add(issue)
    db.commit()
    db.refresh(issue)
    return {"id": issue.id, "message": "의뢰가 접수되었습니다"}

@app.patch("/api/issues/{issue_id}")
def update_issue(issue_id: str, data: IssueUpdate, current_user: User = Depends(require_role("visa_admin","company_admin")), db: Session = Depends(get_db)):
    issue = db.query(Issue).filter(Issue.id == issue_id).first()
    if not issue:
        raise HTTPException(status_code=404, detail="의뢰를 찾을 수 없습니다")
    cid = get_company_filter(current_user)
    if cid and issue.company_id != cid:
        raise HTTPException(status_code=403, detail="접근 권한이 없습니다")
    for k, v in data.dict(exclude_none=True).items():
        setattr(issue, k, v)
    if data.status == "완료":
        issue.resolution_date = datetime.utcnow()
    db.commit()
    return {"message": "수정되었습니다"}

# ── Dashboard Stats ───────────────────────────────────────────────────────────
@app.get("/api/dashboard")
def dashboard(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    cid = get_company_filter(current_user)

    emp_q = db.query(Employee)
    issue_q = db.query(Issue)
    if cid:
        emp_q = emp_q.filter(Employee.company_id == cid)
        issue_q = issue_q.filter(Issue.company_id == cid)

    emps = emp_q.all()
    today = date.today()

    expiring_30  = [e for e in emps if e.expiry_date and days_until(e.expiry_date) <= 30]
    expiring_90  = [e for e in emps if e.expiry_date and 30 < days_until(e.expiry_date) <= 90]
    passport_exp = [e for e in emps if e.passport_expiry and days_until(e.passport_expiry) <= 90]

    open_issues  = issue_q.filter(Issue.status != "완료").count()
    new_issues   = issue_q.filter(Issue.status == "접수").count()

    company_count = db.query(Company).filter(Company.status == "active").count() if current_user.role == "visa_admin" else None

    return {
        "total_employees": len(emps),
        "company_count": company_count,
        "expiring_30": len(expiring_30),
        "expiring_90": len(expiring_90),
        "passport_expiring": len(passport_exp),
        "open_issues": open_issues,
        "new_issues": new_issues,
        "expiring_30_list": [emp_to_dict(e) for e in sorted(expiring_30, key=lambda x: x.expiry_date or "")[:5]],
        "recent_issues": [issue_to_dict(i) for i in issue_q.order_by(Issue.request_date.desc()).limit(5).all()],
    }

# ── Users (Admin only) ────────────────────────────────────────────────────────
@app.get("/api/users")
def list_users(current_user: User = Depends(require_role("visa_admin")), db: Session = Depends(get_db)):
    users = db.query(User).filter(User.is_active == True).all()
    return [{
        "id": u.id, "role": u.role, "username": u.username, "name": u.name,
        "email": u.email, "company_id": u.company_id,
        "company_name": u.company.name if u.company else "법무법인 대림",
        "last_login": u.last_login.strftime("%Y-%m-%d %H:%M") if u.last_login else None,
    } for u in users]

@app.post("/api/users")
def create_user(data: UserCreate, current_user: User = Depends(require_role("visa_admin")), db: Session = Depends(get_db)):
    if db.query(User).filter(User.username == data.username).first():
        raise HTTPException(status_code=400, detail="이미 존재하는 아이디입니다")
    u = User(
        company_id=data.company_id, role=data.role, username=data.username,
        password_hash=hash_password(data.password), name=data.name,
        email=data.email, phone=data.phone,
    )
    db.add(u)
    db.commit()
    return {"message": "계정이 생성되었습니다"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
