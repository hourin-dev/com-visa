#!/bin/bash
# VisaDesk v2 - 서버 시작 스크립트
cd "$(dirname "$0")/backend"
echo "🚀 VisaDesk v2 서버를 시작합니다..."
echo "📌 API 서버: http://localhost:8000"
echo "📌 프론트엔드: frontend/index.html 을 브라우저에서 열거나"
echo "   http://localhost:8000 으로 접속하세요"
echo ""
python main.py
